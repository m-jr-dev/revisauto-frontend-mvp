const API_URL = 'http://localhost:5000';
const fetchOpts = {
  mode: 'cors',
  headers: { 'Content-Type': 'application/json' }
};

let currentUser = null;

// Ativa fundo com wallpaper ao carregar
document.body.classList.add('login-active');

// LOGIN
const loginBtn = document.getElementById('login-btn');
loginBtn.addEventListener('click', async () => {
  const usuario = document.getElementById('login-usuario').value;
  const senha = document.getElementById('login-senha').value;

  const res = await fetch(`${API_URL}/login`, {
    ...fetchOpts,
    method: 'POST',
    body: JSON.stringify({ usuario, senha })
  });
  const result = await res.json();

  if (res.ok) {
    currentUser = result;

    // Remove wallpaper ao logar
    document.body.classList.remove('login-active');

    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('app-header').classList.remove('hidden');
    document.getElementById('user-welcome').innerText = `Olá, ${result.nome_completo}`;

    if (usuario === 'admin') {
      document.getElementById('admin-screen').classList.remove('hidden');
      loadUsuarios();
      bindUsuarioForm();
    } else {
      document.getElementById('user-screen').classList.remove('hidden');
      buildManutencaoForm();
      loadManutencoes();
    }
  } else {
    document.getElementById('login-erro').innerText = result.error || 'Erro no login';
  }
});

function bindUsuarioForm() {
  const form = document.getElementById('usuario-form');
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const payload = {
      nome_completo: document.getElementById('nome_completo').value,
      usuario: document.getElementById('usuario').value,
      senha: document.getElementById('senha').value
    };
    await fetch(`${API_URL}/register`, {
      ...fetchOpts,
      method: 'POST',
      body: JSON.stringify(payload)
    });
    loadUsuarios();
    form.reset();
  });
}

async function loadUsuarios() {
  const res = await fetch(`${API_URL}/usuarios`, fetchOpts);
  const data = await res.json();
  const ul = document.getElementById('usuarios-list');
  ul.innerHTML = '';
  data.forEach(user => {
    const li = document.createElement('li');
    li.textContent = `ID ${user.id} - ${user.nome_completo} (${user.usuario})`;
    ul.appendChild(li);
  });
}

function buildManutencaoForm() {
  const form = document.getElementById('manutencao-form');
  form.innerHTML = `
    <select id="tipo">
      <option disabled selected value="">Selecione o tipo de Manutenção</option>
      <option>Troca de Óleo</option>
      <option>Troca de Filtro de Óleo</option>
      <option>Troca de Filtro de Ar</option>
      <option>Troca de Filtro de Combustível</option>
      <option>Troca de Velas</option>
      <option>Troca de Bateria</option>
      <option>Alinhamento e Balanceamento</option>
      <option>Verificação dos Freios</option>
      <option>Substituição de Correia Dentada</option>
      <option>Troca de Fluido de Freio</option>
      <option>Troca de Fluido de Arrefecimento</option>
      <option>Inspeção Geral</option>
      <option>Outro (especificar)</option>
    </select>
    <div id="tipo-custom" class="hidden">
      <input type="text" id="tipo_manual" placeholder="Descreva o tipo de Manutenção"/>
    </div>
    <input type="number" id="km_atual" placeholder="KM atual" required/>
    <input type="date" id="data" required/>
    <input type="text" id="observacoes" placeholder="Observações"/>
    <input type="number" id="proxima_km" placeholder="Próxima troca (KM)" required/>
    <button type="submit">Salvar</button>
  `;

  document.getElementById('tipo').addEventListener('change', () => {
    document.getElementById('tipo-custom').classList.toggle(
      'hidden',
      document.getElementById('tipo').value !== 'Outro (especificar)'
    );
  });

  form.addEventListener('submit', async e => {
    e.preventDefault();
    const tipo = document.getElementById('tipo').value === 'Outro (especificar)'
      ? document.getElementById('tipo_manual').value
      : document.getElementById('tipo').value;

    const payload = {
      usuario_id: currentUser.usuario_id,
      tipo,
      km_atual: parseInt(document.getElementById('km_atual').value),
      data: document.getElementById('data').value,
      observacoes: document.getElementById('observacoes').value,
      proxima_km: parseInt(document.getElementById('proxima_km').value)
    };

    await fetch(`${API_URL}/manutencao`, {
      ...fetchOpts,
      method: 'POST',
      body: JSON.stringify(payload)
    });

    loadManutencoes();
    form.reset();
    document.getElementById('tipo-custom').classList.add('hidden');
  });
}

async function loadManutencoes() {
  const res = await fetch(`${API_URL}/manutencoes`, fetchOpts);
  const data = await res.json();
  const container = document.getElementById('manutencoes');
  container.innerHTML = '';

  data
    .filter(m => m.usuario_id === currentUser.usuario_id)
    .forEach(m => {
      const div = document.createElement('div');
      div.innerHTML = `
        <strong>
          <i class="fa-solid ${getIconClass(m.tipo)}" style="font-size: 1.5rem; margin-right: 5px;"></i>
          ${m.data}
        </strong> - ${m.tipo} - ${m.km_atual} km<br/>
        <small>${m.observacoes || ''}</small><br/>
        <button onclick="editManutencao(${m.id})">Editar</button>
        <button onclick="deleteManutencao(${m.id})">Excluir</button>
        <button onclick="viewHistorico(${m.id}, this)">Ver Histórico</button>
        <div class="historico hidden" id="historico-${m.id}"></div>
      `;
      container.appendChild(div);
    });
}

async function viewHistorico(manutencaoId, buttonEl) {
  const divHist = document.getElementById(`historico-${manutencaoId}`);
  if (!divHist.classList.contains('hidden')) {
    divHist.classList.add('hidden');
    divHist.innerHTML = '';
    buttonEl.innerText = 'Ver Histórico';
    return;
  }

  const res = await fetch(`${API_URL}/historico/${manutencaoId}`, fetchOpts);
  const historico = await res.json();

  if (historico.length === 0) {
    divHist.innerHTML = '<em>Sem histórico disponível.</em>';
  } else {
    divHist.innerHTML = historico.map(h => `
      <div style="margin: 5px 0; padding: 5px; background: #eee;">
        <strong>${h.acao}</strong> por <strong>${h.nome_completo}</strong> em ${new Date(h.timestamp).toLocaleString()}
      </div>
    `).join('');
  }

  divHist.classList.remove('hidden');
  buttonEl.innerText = 'Ocultar Histórico';
}

async function editManutencao(id) {
  const res = await fetch(`${API_URL}/manutencao/${id}`, fetchOpts);
  const m = await res.json();
  document.getElementById('km_atual').value = m.km_atual;
  document.getElementById('data').value = m.data;
  document.getElementById('observacoes').value = m.observacoes;
  document.getElementById('proxima_km').value = m.proxima_km;
  document.getElementById('tipo').value =
    [...document.getElementById('tipo').options].some(opt => opt.value === m.tipo)
      ? m.tipo
      : 'Outro (especificar)';
  if (document.getElementById('tipo').value === 'Outro (especificar)') {
    document.getElementById('tipo-custom').classList.remove('hidden');
    document.getElementById('tipo_manual').value = m.tipo;
  }
}

async function deleteManutencao(id) {
  if (confirm('Deseja realmente excluir esta manutenção?')) {
    await fetch(`${API_URL}/manutencao/${id}`, {
      ...fetchOpts,
      method: 'DELETE',
      body: JSON.stringify({ usuario_id: currentUser.usuario_id })
    });
    loadManutencoes();
  }
}

function getIconClass(tipo) {
  const icons = {
    "Troca de Óleo": "fa-oil-can",
    "Troca de Filtro de Óleo": "fa-filter",
    "Troca de Filtro de Ar": "fa-wind",
    "Troca de Filtro de Combustível": "fa-gas-pump",
    "Troca de Velas": "fa-bolt",
    "Troca de Bateria": "fa-car-battery",
    "Alinhamento e Balanceamento": "fa-ruler-combined",
    "Verificação dos Freios": "fa-warning",
    "Substituição de Correia Dentada": "fa-gear",
    "Troca de Fluido de Freio": "fa-droplet",
    "Troca de Fluido de Arrefecimento": "fa-temperature-full",
    "Inspeção Geral": "fa-list-check"
  };
  return icons[tipo] || "fa-toolbox";
}
